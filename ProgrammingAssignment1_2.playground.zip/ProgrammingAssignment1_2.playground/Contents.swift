
import Foundation

// Частина 1

// Дано рядок у форматі "Student1 - Group1; Student2 - Group2; ..."

let studentsStr = "Дмитренко Олександр - ІП-84; Матвійчук Андрій - ІВ-83; Лесик Сергій - ІО-82; Ткаченко Ярослав - ІВ-83; Аверкова Анастасія - ІО-83; Соловйов Даніїл - ІО-83; Рахуба Вероніка - ІО-81; Кочерук Давид - ІВ-83; Лихацька Юлія- ІВ-82; Головенець Руслан - ІВ-83; Ющенко Андрій - ІО-82; Мінченко Володимир - ІП-83; Мартинюк Назар - ІО-82; Базова Лідія - ІВ-81; Снігурець Олег - ІВ-81; Роман Олександр - ІО-82; Дудка Максим - ІО-81; Кулініч Віталій - ІВ-81; Жуков Михайло - ІП-83; Грабко Михайло - ІВ-81; Іванов Володимир - ІО-81; Востриков Нікіта - ІО-82; Бондаренко Максим - ІВ-83; Скрипченко Володимир - ІВ-82; Кобук Назар - ІО-81; Дровнін Павло - ІВ-83; Тарасенко Юлія - ІО-82; Дрозд Світлана - ІВ-81; Фещенко Кирил - ІО-82; Крамар Віктор - ІО-83; Іванов Дмитро - ІВ-82"

// Завдання 1
// Заповніть словник, де:
// - ключ – назва групи
// - значення – відсортований масив студентів, які відносяться до відповідної групи

var studentsGroups: [String: [String]] = [:]

// Ваш код починається тут

var studentsArr = studentsStr.components(separatedBy: "; ")
studentsArr = studentsArr.sorted()

//Імена що починаються на "І" некорректно відсортовуються дефолним алгоритмом. Коррекція:
var Ivanov0 = studentsArr[0]
var Ivanov1 = studentsArr[1]
studentsArr.remove(at: 0)
studentsArr.remove(at: 0)
studentsArr.insert(Ivanov0, at: 11)
studentsArr.insert(Ivanov1, at: 12)

var tempArr = [String]()
for i in 0...studentsArr.count-1 {
    tempArr.append(contentsOf: studentsArr[i].components(separatedBy: " - "))
}
studentsArr = tempArr
tempArr = []
var IO81 = [String](); var IO82 = [String](); var IO83 = [String]()
var IV81 = [String](); var IV82 = [String](); var IV83 = [String]()
var IP83 = [String]()
for i in 0...studentsArr.count-1 {
    if studentsArr[i]=="ІО-81"{
        IO81.append(studentsArr[i-1])
    }else if studentsArr[i]=="ІО-82"{
        IO82.append(studentsArr[i-1])
    }else if studentsArr[i]=="ІО-83"{
        IO83.append(studentsArr[i-1])
    }else if studentsArr[i]=="ІВ-81"{
        IV81.append(studentsArr[i-1])
    }else if studentsArr[i]=="ІВ-82"{
        IV82.append(studentsArr[i-1])
    }else if studentsArr[i]=="ІВ-83"{
        IV83.append(studentsArr[i-1])
    }else if studentsArr[i]=="ІП-83"{
        IP83.append(studentsArr[i-1])
    }
    
}
studentsGroups = ["IO-81":IO81, "ІО-82":IO82, "ІО-83":IO83, "ІВ-81": IV81,"ІВ-82":IV82,"ІВ-83":IV83,"ІП-83":IP83]
// Ваш код закінчується тут

print("Завдання 1")
print(studentsGroups)
print()

// Дано масив з максимально можливими оцінками

let points: [Int] = [12, 12, 12, 12, 12, 12, 12, 16]

// Завдання 2
// Заповніть словник, де:
// - ключ – назва групи
// - значення – словник, де:
//   - ключ – студент, який відносяться до відповідної групи
//   - значення – масив з оцінками студента (заповніть масив випадковими значеннями, використовуючи функцію `randomValue(maxValue: Int) -> Int`)

func randomValue(maxValue: Int) -> Int {
    switch(arc4random_uniform(6)) {
    case 1:
        return Int(ceil(Float(maxValue) * 0.7))
    case 2:
        return Int(ceil(Float(maxValue) * 0.9))
    case 3, 4, 5:
        return maxValue
    default:
        return 0
    }
}

var studentPoints: [String: [String: [Int]]] = [:]

// Ваш код починається тут

func randomPointsGen(MaxPointsArr: [Int]) -> [Int]{
    var randomPoints : [Int] = []
    for i in 0...MaxPointsArr.count-1{
        randomPoints.append(randomValue(maxValue: MaxPointsArr[i]))
    }
    return randomPoints
}


var IO81_Points: [String: [Int]] = [:]
for student in 0...IO81.count-1{
    IO81_Points[IO81[student]] = randomPointsGen(MaxPointsArr: points)
}
var IO82_Points: [String: [Int]] = [:]
for student in 0...IO82.count-1{
    IO82_Points[IO82[student]] = randomPointsGen(MaxPointsArr: points)
}
var IO83_Points: [String: [Int]] = [:]
for student in 0...IO83.count-1{
    IO83_Points[IO83[student]] = randomPointsGen(MaxPointsArr: points)
}
var IV81_Points: [String: [Int]] = [:]
for student in 0...IV81.count-1{
    IV81_Points[IV81[student]] = randomPointsGen(MaxPointsArr: points)
}
var IV82_Points: [String: [Int]] = [:]
for student in 0...IV82.count-1{
    IV82_Points[IV82[student]] = randomPointsGen(MaxPointsArr: points)
}
var IV83_Points: [String: [Int]] = [:]
for student in 0...IV83.count-1{
    IV83_Points[IV83[student]] = randomPointsGen(MaxPointsArr: points)
}
var IP83_Points: [String: [Int]] = [:]
for student in 0...IP83.count-1{
    IP83_Points[IP83[student]] = randomPointsGen(MaxPointsArr: points)
}

studentPoints = ["IO-81":IO81_Points, "ІО-82":IO82_Points, "ІО-83":IO83_Points, "ІВ-81": IV81_Points,"ІВ-82":IV82_Points,"ІВ-83":IV83_Points,"ІП-83":IP83_Points]

// Ваш код закінчується тут

print("Завдання 2")
print(studentPoints)
print()

// Завдання 3
// Заповніть словник, де:
// - ключ – назва групи
// - значення – словник, де:
//   - ключ – студент, який відносяться до відповідної групи
//   - значення – сума оцінок студента

var sumPoints: [String: [String: Int]] = [:]

// Ваш код починається тут

func arrSum(Arr: [Int]) -> Int{
    var sum = 0
    for i in 0...Arr.count-1{
        sum += Arr[i]
    }
    return sum
}


var IO81_SumPoints: [String: Int] = [:]; var IO82_SumPoints: [String: Int] = [:]; var IO83_SumPoints: [String: Int] = [:]
var IV81_SumPoints: [String: Int] = [:]; var IV82_SumPoints: [String: Int] = [:]; var IV83_SumPoints: [String: Int] = [:]
var IP83_SumPoints: [String: Int] = [:]

for (key, value) in IO81_Points{
    IO81_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}
for (key, value) in IO82_Points{
    IO82_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}
for (key, value) in IO82_Points{
    IO82_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}
for (key, value) in IO83_Points{
    IO83_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}
for (key, value) in IV81_Points{
    IV81_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}
for (key, value) in IV82_Points{
    IV82_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}
for (key, value) in IV83_Points{
    IV83_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}
for (key, value) in IP83_Points{
    IP83_SumPoints.updateValue(arrSum(Arr: value), forKey: key)
}

sumPoints = ["IO-81":IO81_SumPoints,  "ІО-82":IO82_SumPoints, "ІО-83":IO83_SumPoints, "ІВ-81": IV81_SumPoints,"ІВ-82":IV82_SumPoints,"ІВ-83":IV83_SumPoints,"ІП-83":IP83_SumPoints]

// Ваш код закінчується тут

print("Завдання 3")
print(sumPoints)
print()

// Завдання 4
// Заповніть словник, де:
// - ключ – назва групи
// - значення – середня оцінка всіх студентів групи

var groupAvg: [String: Float] = [:]

// Ваш код починається тут

var numOfStudents = 0
var IO81_All: Int = 0
for (_,value) in IO81_SumPoints{
    IO81_All += value
    numOfStudents+=1
}
var IO81_Avg: Float = Float(IO81_All) / Float(numOfStudents)

var IO82_All: Int = 0; numOfStudents = 0
for (_,value) in IO82_SumPoints{
    IO82_All += value
    numOfStudents+=1
}
var IO82_Avg: Float = Float(IO82_All) / Float(numOfStudents)

var IO83_All: Int = 0; numOfStudents = 0
for (_,value) in IO83_SumPoints{
    IO83_All += value
    numOfStudents+=1
}
var IO83_Avg: Float = Float(IO83_All) / Float(numOfStudents)

var IV81_All: Int = 0; numOfStudents = 0
for (_,value) in IV81_SumPoints{
    IV81_All += value
    numOfStudents+=1
}
var IV81_Avg: Float = Float(IV81_All) / Float(numOfStudents)

var IV82_All: Int = 0; numOfStudents = 0
for (_,value) in IV82_SumPoints{
    IV82_All += value
    numOfStudents+=1
}
var IV82_Avg: Float = Float(IV82_All) / Float(numOfStudents)

var IV83_All: Int = 0; numOfStudents = 0
for (_,value) in IV83_SumPoints{
    IV83_All += value
    numOfStudents+=1
}
var IV83_Avg: Float = Float(IV83_All) / Float(numOfStudents)

var IP83_All: Int = 0; numOfStudents = 0
for (_,value) in IP83_SumPoints{
    IP83_All += value
    numOfStudents+=1
}
var IP83_Avg: Float = Float(IP83_All) / Float(numOfStudents)

groupAvg = ["IO-81":IO81_Avg, "ІО-82":IO82_Avg, "ІО-83":IO83_Avg, "ІВ-81": IV81_Avg,"ІВ-82":IV82_Avg,"ІВ-83":IV83_Avg,"ІП-83":IP83_Avg]

// Ваш код закінчується тут

print("Завдання 4")
print(groupAvg)
print()

// Завдання 5
// Заповніть словник, де:
// - ключ – назва групи
// - значення – масив студентів, які мають >= 60 балів

var passedPerGroup: [String: [String]] = [:]

// Ваш код починається тут

var IO81_Passed: [String] = []; var IO82_Passed: [String] = []; var IO83_Passed: [String] = []
var IV81_Passed: [String] = []; var IV82_Passed: [String] = []; var IV83_Passed: [String] = []
var IP83_Passed: [String] = []

for (key, value) in IO81_SumPoints{
    if value>=60{
        IO81_Passed.append(key)
    }
}
for (key, value) in IO82_SumPoints{
    if value>=60{
        IO82_Passed.append(key)
    }
}
for (key, value) in IO83_SumPoints{
    if value>=60{
        IO83_Passed.append(key)
    }
}
for (key, value) in IV81_SumPoints{
    if value>=60{
        IV81_Passed.append(key)
    }
}
for (key, value) in IV82_SumPoints{
    if value>=60{
        IV82_Passed.append(key)
    }
}
for (key, value) in IV83_SumPoints{
    if value>=60{
        IV83_Passed.append(key)
    }
}
for (key, value) in IP83_SumPoints{
    if value>=60{
        IP83_Passed.append(key)
    }
}

passedPerGroup = ["IO-81":IO81_Passed, "ІО-82":IO82_Passed, "ІО-83":IO83_Passed, "ІВ-81": IV81_Passed,"ІВ-82":IV82_Passed,"ІВ-83":IV83_Passed,"ІП-83":IP83_Passed]

// Ваш код закінчується тут

print("Завдання 5")
print(passedPerGroup)

// Приклад виведення. Ваш результат буде відрізнятися від прикладу через використання функції random для заповнення масиву оцінок та через інші вхідні дані.
//
//Завдання 1
//["ІВ-73": ["Гончар Юрій", "Давиденко Костянтин", "Капінус Артем", "Науменко Павло", "Чередніченко Владислав"], "ІВ-72": ["Бортнік Василь", "Киба Олег", "Овчарова Юстіна", "Тимко Андрій"], "ІВ-71": ["Андрющенко Данило", "Гуменюк Олександр", "Корнійчук Ольга", "Музика Олександр", "Трудов Антон", "Феофанов Іван"]]
//
//Завдання 2
//["ІВ-73": ["Давиденко Костянтин": [5, 8, 9, 12, 11, 12, 0, 0, 14], "Капінус Артем": [5, 8, 12, 12, 0, 12, 12, 12, 11], "Науменко Павло": [4, 8, 0, 12, 12, 11, 12, 12, 15], "Чередніченко Владислав": [5, 8, 12, 12, 11, 12, 12, 12, 15], "Гончар Юрій": [5, 6, 0, 12, 0, 11, 12, 11, 14]], "ІВ-71": ["Корнійчук Ольга": [0, 0, 12, 9, 11, 11, 9, 12, 15], "Музика Олександр": [5, 8, 12, 0, 11, 12, 0, 9, 15], "Гуменюк Олександр": [5, 8, 12, 9, 12, 12, 11, 12, 15], "Трудов Антон": [5, 0, 0, 11, 11, 0, 12, 12, 15], "Андрющенко Данило": [5, 6, 0, 12, 12, 12, 0, 9, 15], "Феофанов Іван": [5, 8, 12, 9, 12, 9, 11, 12, 14]], "ІВ-72": ["Киба Олег": [5, 8, 12, 12, 11, 12, 0, 0, 11], "Овчарова Юстіна": [5, 8, 12, 0, 11, 12, 12, 12, 15], "Бортнік Василь": [4, 8, 12, 12, 0, 12, 9, 12, 15], "Тимко Андрій": [0, 8, 11, 0, 12, 12, 9, 12, 15]]]
//
//Завдання 3
//["ІВ-72": ["Бортнік Василь": 84, "Тимко Андрій": 79, "Овчарова Юстіна": 87, "Киба Олег": 71], "ІВ-73": ["Капінус Артем": 84, "Науменко Павло": 86, "Чередніченко Владислав": 99, "Гончар Юрій": 71, "Давиденко Костянтин": 71], "ІВ-71": ["Корнійчук Ольга": 79, "Трудов Антон": 66, "Андрющенко Данило": 71, "Гуменюк Олександр": 96, "Феофанов Іван": 92, "Музика Олександр": 72]]
//
//Завдання 4
//["ІВ-71": 79.333336, "ІВ-72": 80.25, "ІВ-73": 82.2]
//
//Завдання 5
//["ІВ-72": ["Бортнік Василь", "Киба Олег", "Овчарова Юстіна", "Тимко Андрій"], "ІВ-73": ["Давиденко Костянтин", "Капінус Артем", "Чередніченко Владислав", "Гончар Юрій", "Науменко Павло"], "ІВ-71": ["Музика Олександр", "Трудов Антон", "Гуменюк Олександр", "Феофанов Іван", "Андрющенко Данило", "Корнійчук Ольга"]]


print("\nPart two:\n")
//Part Two

enum Direction{
    case longitude
    case latitude
}

enum CoordinateError: Error{
    case InvalidCoordinateGiven(nameOfCoordinate: String)
    case TwoCoordinatesGivenHaveDifferentDirections
}


class CoordinateAR{
    
    var degrees:Int = 0
    var minutes:UInt = 0
    var seconds:UInt = 0
    var IsLongitude: Bool = false
    var IsLatitude: Bool = false
    var direction: Direction
    
    init(degrees: Int, minutes: UInt, seconds: UInt, direction: Direction) throws{
        self.degrees = degrees
        self.minutes = minutes
        self.seconds = seconds
        self.direction = direction

        if direction == .latitude{
            self.IsLatitude = true
        }else if direction == .longitude{
            self.IsLongitude = true
        }else{ throw CoordinateError.InvalidCoordinateGiven(nameOfCoordinate: "direction") }
        
        if (self.IsLongitude && ((degrees > 180) || (degrees < -180))) || (self.IsLatitude && ((degrees > 90) || (degrees < -90))){
            throw CoordinateError.InvalidCoordinateGiven(nameOfCoordinate: "degrees")
        }
        if (minutes > 59) || (minutes < 0){
            throw CoordinateError.InvalidCoordinateGiven(nameOfCoordinate: "minutes")
        }
        if (seconds > 59) || (seconds < 0){
            throw CoordinateError.InvalidCoordinateGiven(nameOfCoordinate: "seconds")
        }
        if (self.IsLongitude && ((degrees == 180) || (degrees == -180))) || (self.IsLatitude && ((degrees == 90) || (degrees == -90))){
            if (minutes != 0) || (seconds != 0){ throw CoordinateError.InvalidCoordinateGiven(nameOfCoordinate: "Coordinates out of bounds") }
        }
    }
    
    init(direction: Direction) throws {
        // zero Init
        self.degrees = 0
        self.minutes = 0
        self.seconds = 0
        self.direction = direction
        if direction == .latitude{
            self.IsLatitude = true
        }else if direction == .longitude{
            self.IsLongitude = true
        }else{ throw CoordinateError.InvalidCoordinateGiven(nameOfCoordinate: "direction") }
    }
    
    func avgCoordinate(SecondCoordinate: CoordinateAR) throws -> CoordinateAR?{
        let SecondCoordinate = SecondCoordinate
        let AvgCoordinate = try CoordinateAR(degrees: 0, minutes: 0, seconds: 0, direction: .latitude)
        if self.direction != SecondCoordinate.direction{
            print("avgCoordinate Warning: two coordinates given have different directions!")
            return nil
        }
        
        AvgCoordinate.degrees = (self.degrees + SecondCoordinate.degrees)/2
        AvgCoordinate.minutes = (self.minutes + SecondCoordinate.minutes)/2
        AvgCoordinate.seconds = (self.seconds + SecondCoordinate.seconds)/2
        AvgCoordinate.direction = self.direction
        return AvgCoordinate
    }
    
    func avgCoordinate(FirstCoordinate: CoordinateAR, SecondCoordinate: CoordinateAR) throws -> CoordinateAR?{
        let FirstCoordinate = FirstCoordinate
        let SecondCoordinate = SecondCoordinate
        let AvgCoordinate = try CoordinateAR(direction: .latitude)
        if FirstCoordinate.direction != SecondCoordinate.direction{
            print("avgCoordinate Warning: two coordinates given have different directions!")
            return nil
        }
        
        AvgCoordinate.degrees = (FirstCoordinate.degrees + SecondCoordinate.degrees)/2
        AvgCoordinate.minutes = (FirstCoordinate.minutes + SecondCoordinate.minutes)/2
        AvgCoordinate.seconds = (FirstCoordinate.seconds + SecondCoordinate.seconds)/2
        AvgCoordinate.direction = FirstCoordinate.direction
        return AvgCoordinate
    }
    
    func printer1() -> String{
        var printStr = ""
        var dirStr = ""
        let deg = self.degrees
        let degStr = String(deg)
        let min = self.minutes
        let minStr = String(min)
        let sec = self.seconds
        let secStr = String(sec)
        if self.direction == .latitude{
            dirStr = "latitude"
        }else{ dirStr = "longitude" }
        printStr += degStr + "°" + minStr + "′" + secStr + "\" " + dirStr
        return printStr
    }
    
    func printer2() -> String{
        var printStr = ""
        var dirStr = ""
        var deg: Float = 0.0 + Float(self.degrees)
        let min = self.minutes
        let sec = self.seconds
        if deg < 0{
            deg -= (Float(min)/60) - (Float(sec)/3600)
        }else{
            deg += (Float(min)/60) + (Float(sec)/3600)
        }
        let degStr = String(deg)
        if self.direction == .latitude{
            dirStr = "latitude"
        }else{ dirStr = "longitude" }
        
        printStr += degStr + "° " + dirStr
        return printStr
    }
}

var Coordinate0 = try CoordinateAR(direction: .latitude)
var Coordinate1	= try CoordinateAR(degrees: 160, minutes: 30, seconds: 30, direction: .longitude)
var Coordinate2 = try CoordinateAR(degrees: 30, minutes: 20, seconds: 20, direction: .longitude)
var Coordinate3 = try CoordinateAR(degrees: -60, minutes: 0, seconds: 10, direction: .latitude)

print("Coordinate0: " + Coordinate0.printer1())
print("Coordinate0: " + Coordinate0.printer2())
print("Coordinate1: " + Coordinate1.printer1())
print("Coordinate1: " + Coordinate1.printer2())
print("Coordinate2: " + Coordinate2.printer1())
print("Coordinate2: " + Coordinate2.printer2())
print("Coordinate3: " + Coordinate3.printer1())
print("Coordinate3: " + Coordinate3.printer2() + "\n")

var AvgCoordinate12 = try Coordinate1.avgCoordinate(SecondCoordinate: Coordinate2)
var AvgCoordinate03: CoordinateAR? = try CoordinateAR(direction: .latitude)
AvgCoordinate03 = try AvgCoordinate03?.avgCoordinate(FirstCoordinate: Coordinate0, SecondCoordinate: Coordinate3)

if AvgCoordinate12 != nil{
    print("The average between 1 and 2 is: " + AvgCoordinate12!.printer1())
}
if AvgCoordinate03 != nil{
    print("The average between 0 and 3 is: " + AvgCoordinate03!.printer1())
}
